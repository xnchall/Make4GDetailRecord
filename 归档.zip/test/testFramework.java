package cn.chinaunicom.test;


public class testFramework {

	public static void main(String[] args) {
		//BaseFramework p = new BaseFramework();
		
	}
	
}
