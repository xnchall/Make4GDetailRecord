package cn.chinaunicom.test;
/*
 * ������     junit
 */
import org.junit.Test;
import cn.chinaunicom.FrameWork.*;
import cn.chinaunicom.IO.*;
import cn.chinaunicom.renameFile.renameFile;


public class testDemo {

	@Test
	public void TestReadFile() {
		System.out.println(readFile.readfile());
	}
	
	@Test
	public void Testintercept() {
		for(int i = 0; i < read4GdetailFile.interceptStr().length; i++)
			System.out.println(read4GdetailFile.interceptStr()[i]);
		//System.out.println(read4GdetailFile.interceptStr()[0]);
	}
	
	@Test
	public void TestFix() {
		String s = "123456";
		for(int i = 0; i < read4GdetailFile.fixStr(s, s, s, s, s, s).length; i++){
			System.out.println(read4GdetailFile.fixStr(s, s, s, s, s, s)[i]);
		}
		//read4GdetailFile.fixStr(s, s, s, s, s, s);
	}
	
	@Test
	public void TestinterceptStr(){
		read4GdetailFile.interceptStr();
	}
	
	@Test
	public void TestFramework(){
		
		new BaseFramework();
		
	}
	
	@Test
	public void TestinterceptName(){
		
		String cycle_id = "20160408";
		renameFile.interceptName(cycle_id);
		//System.out.println(t);
	}
}
