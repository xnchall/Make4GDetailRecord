package cn.chinaunicom.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.junit.Test;

public class testJar {

	@Test
	public void teat(){
		
		//getResource();
		substr();
	}
	
	public void getResource() {
		
		InputStream is = this.getClass().getResourceAsStream("/GPP1101_0110110GJSJ0190052900201509170101103AR5.0.a.out.C.1509.20150917000195");
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		String s= "t";
		try {
			while((s = br.readLine()) != null){
				System.out.println(s);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void substr() {
		String str = "20160408";
		System.out.println(str.substring(0, 6));
	}

}
