package cn.chinaunicom.test;

public class testLength {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "20160101";
		System.out.println(str.length());
		
		
	}

}
