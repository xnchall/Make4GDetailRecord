package cn.chinaunicom.IO;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import cn.chinaunicom.renameFile.renameFile;

public class writeFile1 {

	public static String writefile(String serialNumber1
			,String Cycle_ID1
			,String province1
			,String attribution1
			,String user_ID1
			,String acct_ID1){
		
		String[] writeStr = null;   //�����ļ����ݵ��ַ�����
		StringBuffer temp = new StringBuffer();
		
		String fileName = renameFile.interceptName(Cycle_ID1);
		//System.out.println(fileName);
		String dir = "E:";
		File file = new File(dir, fileName);
		OutputStream os = null;
		try {
			
			os = new FileOutputStream(file, false);
			writeStr = read4GdetailFile.fixStr(serialNumber1,Cycle_ID1,province1,attribution1,user_ID1,acct_ID1);
			/*for(int i = 0; i < writeStr.length - 1;i++)
				System.out.println(writeStr[i]);*/
			for(int i = 0; i < writeStr.length - 1;i++)
				temp.append(writeStr[i]+",");
			temp.append(writeStr[writeStr.length-1]);
			String newTempStr = temp.toString();
			System.out.println(newTempStr);
			byte[] data = newTempStr.getBytes();
			os.write(data, 0, data.length);	
			os.flush();                             //ǿ��ˢ�³�ȥ
			System.out.println("�ļ�д��ɹ���");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("�ļ�δ�ҵ�");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("�ļ�д��ʧ��");
		}finally{
			if(os != null){}
			try {
				os.close();
			} catch (IOException e) {
				System.out.println("�ر������ʧ��");
			}
		}
		return file.toString();
	}
}
